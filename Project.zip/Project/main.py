from digital_adventures_pkg import game as g
from digital_adventures_pkg import characters as c

g.start_game(g.start_game)
