from digital_adventures_pkg import game as g
import random


class Characters:

    def door_one(self):
        print("One Man’s Garbage Is Another Bear’s Treasure\n")

        print("You must battle the Bear to survive and return home to your beautiful spouse!\n")

        task = input("Will you fight or will you run? \n")

        while True:
            if task.lower() == "FIGHT".lower():
                new_weapon = random.choice(weapon)
                print(
                    f"\nLook at that there's a {new_weapon} to help you fight off this Giant Bear\n")

                print(
                    f"\nBears are known for digging through trash and wrecking campsites just to steal a little food. \nWhen {g.user_name}  discovered a bear hiding out in a dumpster behind a store in Steamboat Springs, Colorado, he didn’t let the bruin get away with it.\n")
                print(f"\n{g.user_name} amusingly addresses the bear in an annoyed voice to exit the dumpster and leave. \nBegrudgingly, the bear listens, climbs out, and waddles off with a few sulking side-eye glances back to the trove of trash.")

                print(
                    f"\n{g.user_name} you're really lucky! I'm not sure if that {new_weapon} was a match for that giant Gizzly Bear o_0 \n")

                print("It looks like someone will make it home after all\n")
                g.show_homepage()
            elif task.lower() == "RUN".lower():
                print(
                    f"\nSorry {g.user_name} you may have got away from the Bear but unfortunately there's a Fire Breathing Dragon on the loose o_0 \n")
                print("""Well that didn't end well \n
                     ☠️
                    \|/
                     |
                    / \              
                """)
                print("\nBetter luck next time!")
                g.show_homepage()
            else:
                task = input("Will you fight or will you run? ")

# Creating methods for each room and will call them when the user choose the different options

    def door_two(self):
        friend = random.choice(friends)
        new_monster = random.choice(monster)

        print("Are Monsters really real?...\n")

        print("You must conquer your fear to return home to your beautiful spouse!\n")

        task = input("Will you over come your fear or hide: YES or NO \n")

        while True:
            if task.lower() == "YES".lower() or task.lower() == "Conquer".lower():

                print(
                    f"\nToday is your lucky day {friend} is her to help you conquer your fear of Monsters\n")

                print(
                    f"\nMost monsters are known for eating people and terriorizing cities. \n When {g.user_name} opened Door Two, it automatically shut and locked behind them")
                print(f"\n{g.user_name} encountered {new_monster} alseep trying not to awake it. {g.user_name} did so anyways because they sneezed due to being allergic to {new_monster}s")

                print(
                    f"\n{new_monster} began charging at {friend}. But luckily, it fell back asleep because of it's sleeping disorder\n")
                print(
                    "{g.user_name} is a professional locksmith so they were able to pick the lock and make it back home safely.")
                print("\nIt looks like everyone will make it home after all\n")
                exit()
            elif task.lower() == "HIDE".lower() or task.lower() == "No".lower():
                print(
                    f"\nSorry {g.user_name} {friend} came to surpise you but since you ran away they were eaten by {new_monster} \n")
                print(
                    "It looks like you will be planning a funeral with no body for the casket\n")
                print("""
                     ☠️
                    \|/
                     |
                    / \

                """)
                print("\n Hopefully, you'll conquer your fears next time!")
                break
            else:
                task = input("Will you fight or will you run? ")

    def door_three(self):
        rand_coast = random.choice(coast)
        friend = random.choice(friends)
        people = random.choice(persons)
        animal = random.choice(animals or people)

        print("Treasure Hunt...\n")

        print(f"There's a hidden treasure at the coast of {rand_coast}\n")

        task = input("Do you want to search it: YES or NO \n")

        while True:
            if task.lower() == "YES".lower():

                print(
                    f"\nAfter building a raft and floating the {rand_coast} you finally made it to the beginning of the trail. \n")
                print(
                    f"\nWith the help of {friend} you are able to read the map. \nWhen {g.user_name} began digging after locating the X that marked the spot.")
                print(f"\n{g.user_name} and {friend} encountered {animal} they weren't expecting that. {animal} approached them demanding {g.user_name} and {friend} to tell them what they were digging for.")
                print(
                    f"{g.user_name} told them what they were looking for.... (Was this a mistake...)")
                print("""
                         .
                         .
                         .
                """)
                print(
                    f"\n{animal} began helping {g.user_name} dig for the treasure. Luckily, they were nice and didn't steal the treasure\n")
                exit()
            elif task.lower() == "No".lower():
                print(
                    f"\n{friend} went without you! They now own two Mars and Jupiter\n")
                print("And you died because you couldn't afford food")
                print("""
                     ☠️
                    \|/
                     |
                    / \              
                """)

                print("\nBetter luck next time")
                break
            else:
                task = input("Do you want to search it: YES or NO \n")

    def door_four(self):
        print("""Door 4 is locked \n
        Yeah I know, this game sucks.
        """)
        g.show_homepage()


weapon = ["sword", "AR-15", "pair of magical tube socks", "ugly duckling"]
monster = ["Big Foot", "Little EYE monster",
           "Cookie Monster", "Hungarian Razorback Monster"]
friends = ["Cliford the Big Red Dog",
           "Tom and Jerry", "Spongebob", "Your spouse"]
coast = ["Montego Bay", "Atlantis Sea",
         "Black Sea", "Ohio River", "Gulf Of Mexico"]
animals = ["a pack of wolverines", "a pack of mutated monkeys", "", ]
persons = ["group of vilage people", "Captin Jack", "a drug cartel"]


character = Characters()
