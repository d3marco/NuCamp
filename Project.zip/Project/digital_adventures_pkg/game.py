from digital_adventures_pkg import characters as c


class Game:

    def __init__(self, start_game, username):
        self.start_game = start_game(start_game)
        self.username = username
        username = user_name


def start_game(self):
    play = input("Would you like to play a game ? \n")
    while True:

        if play.lower() == "Yes".lower():
            print("Choose from the following options \n")
            show_homepage()
            option = input("Which selection would you like? \n")
            if option == "1" or option.lower() == "DOOR ONE".lower():
                print("You selected Door One \n .... EnTER aT YoUR oWn RISK!... \n")
                c.character.door_one()
                break
            elif option == "2" or option.lower() == "DOOR TWO".lower():
                print("You selected Door Two \n .... thIS ShouLD BE iNTERestinG!... \n")
                c.character.door_two()
            elif option == "3" or option.lower() == "DOOR THREE".lower():
                print("You selected Door Three \n .... i CAnT belIEVE tHIs!... \n")
                c.character.door_three()
            elif option == "4" or option.lower() == "DOOR FOUR".lower():
                c.character.door_four()
            elif option == "5" or option.lower() == "Exit".lower():
                exit("What a loser!")
        elif play.lower() == "No".lower():
            print(f"Okay {user_name} maybe next time! \n")
            exit()
        else:
            start_game(start_game)
            return False


def show_homepage():
    print("""
                 === Story Time ===
      -----------------------------------------
      |   1.  Door One    | 2. Door Two        |
      -----------------------------------------
      |   3.  Door Three  | 4. Door Four       |
      -----------------------------------------
      |               5.  Exit                 |
      ----------------------------------------- """)


print("Hi")
user_name = input("... actually what is your name? \n")
print(f"Hi {user_name} it's nice to offically meet you! \n")

